<ifmodule mod_deflate.c>
Addtype font/truetype .ttf
AddOutputFilterByType DEFLATE text/text text/html text/plain text/xml text/css application/x-javascript application/javascript text/javascript font/truetype
</ifmodule>
