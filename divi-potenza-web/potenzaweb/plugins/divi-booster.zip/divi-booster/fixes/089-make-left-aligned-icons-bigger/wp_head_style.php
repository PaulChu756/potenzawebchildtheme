.et_pb_blurb_position_left .et_pb_main_blurb_image { width: 96px !important; }
.et_pb_blurb_position_left img { height: 96px !important; }
.et_pb_blurb_position_left .et-pb-icon { font-size: 96px !important; }