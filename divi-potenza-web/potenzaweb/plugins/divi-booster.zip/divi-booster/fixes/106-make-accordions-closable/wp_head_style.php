.et_pb_toggle_open .et_pb_toggle_title:after { 
	position: absolute;
    top: 50%;
    right: 0;
    margin-top: -0.5em;
    color: #ccc;
    font-size: 16px;
    content: "\e04f"; 
    font-family: "ETmodules" !important;
    font-weight: normal;
    font-style: normal;
    font-variant: normal;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    line-height: 1;
    text-transform: none;
    speak: none;
}