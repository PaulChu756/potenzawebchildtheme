jQuery(function($){
	$('.et_pb_more_button').attr('target', '_blank');
});