.et_pb_slider:not(.et_pb_post_slider) .et-pb-controllers a {
    background-color: transparent;
    border: 1px solid #fff;
}