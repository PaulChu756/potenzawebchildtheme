.et_pb_slide_image, .et_pb_slide:first-child .et_pb_slide_image img.active {
	-webkit-animation: none !important;
	-moz-animation: none !important;
	-o-animation: none !important;
	-ms-animation: none !important;
	animation: none !important;
}