.et_pb_slider .et-pb-controllers a {
    border-radius: 0 !important;
}