<?php
function db129_user_css($plugin) { ?>
.et-fb .et_pb_column > .et_pb_module:hover:after,
.et-fb .et_pb_section > .et_pb_module:hover:after {
    content: "";
    position: absolute;
    bottom: 0; top: 0; left: 0; right: 0;
    border: 2px solid rgb(76, 88, 102);
}
<?php 
}
add_action('wp_head.css', 'db129_user_css');